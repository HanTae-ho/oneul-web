package io.github.hantae_ho.twa;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!ReminderScheduler.ACTION_REMINDER.equals(intent.getAction())) return;
        String id = intent.getStringExtra("id");
        Reminder r = ReminderStore.byId(context, id == null ? "" : id);
        if (r == null || !ReminderStore.enabled(context)) return;
        NotificationHelper.showReminder(context, r);
        // One-shot alarm: immediately schedule this reminder for its next day.
        ReminderScheduler.schedule(context, r);
    }
}
