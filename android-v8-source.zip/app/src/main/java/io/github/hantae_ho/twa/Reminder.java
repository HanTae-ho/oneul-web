package io.github.hantae_ho.twa;

final class Reminder {
    final String id;
    final String type;
    final String label;
    final String time;
    final String detailBody;

    Reminder(String id, String type, String label, String time, String detailBody) {
        this.id = id;
        this.type = type;
        this.label = label;
        this.time = time;
        this.detailBody = detailBody;
    }
}
