package io.github.hantae_ho.twa;

public class MainActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {
    // TWA shell. Native reminder settings are opened by oneul://reminders.
}
