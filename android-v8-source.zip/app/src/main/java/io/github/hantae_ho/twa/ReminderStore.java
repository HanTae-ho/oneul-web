package io.github.hantae_ho.twa;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

final class ReminderStore {
    static final String PREFS = "oneul_native_reminders_v1";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_DETAILED = "detailed";
    static final String KEY_RISK = "risk";
    static final String KEY_MEDS = "meds";
    static final String KEY_EATS = "eats";
    static final String KEY_BED = "bed";
    static final String KEY_BUILD = "web_build";

    private ReminderStore() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return prefs(c).getBoolean(KEY_ENABLED, false); }
    static boolean detailed(Context c) { return prefs(c).getBoolean(KEY_DETAILED, false); }

    static void importSchedule(Context c, String risk, String meds, String eats, String bed, String build) {
        ReminderScheduler.cancelAll(c);
        prefs(c).edit()
            .putString(KEY_RISK, safe(risk))
            .putString(KEY_MEDS, safe(meds))
            .putString(KEY_EATS, safe(eats))
            .putString(KEY_BED, safe(bed))
            .putString(KEY_BUILD, safe(build))
            .apply();
    }

    static void setEnabled(Context c, boolean v) {
        prefs(c).edit().putBoolean(KEY_ENABLED, v).apply();
        if (v) ReminderScheduler.scheduleAll(c); else ReminderScheduler.cancelAll(c);
    }

    static void setDetailed(Context c, boolean v) {
        prefs(c).edit().putBoolean(KEY_DETAILED, v).apply();
    }

    static List<Reminder> reminders(Context c) {
        SharedPreferences p = prefs(c);
        return fromPacked(p.getString(KEY_RISK, ""), p.getString(KEY_MEDS, ""),
            p.getString(KEY_EATS, ""), p.getString(KEY_BED, ""));
    }

    static List<Reminder> fromPacked(String risk, String meds, String eats, String bed) {
        List<Reminder> out = new ArrayList<>();

        if (!risk.isEmpty()) {
            for (String x : risk.split(",")) {
                try {
                    int h = Integer.parseInt(x.trim());
                    if (h >= 0 && h <= 23) {
                        String t = String.format(java.util.Locale.US, "%02d:00", h);
                        out.add(new Reminder("risk_" + h, "risk", h + "시 위험시간대", t,
                            "예전에 힘들던 시간대입니다. 잠시 지금 상태를 살펴보세요."));
                    }
                } catch (Exception ignored) {}
            }
        }
        parseSlots(out, meds, true);
        parseSlots(out, eats, false);
        if (validTime(bed)) {
            out.add(new Reminder("sleep_bed", "sleep", "잘 시간", bed,
                "잘 시간입니다. 잠이 회복을 지켜줍니다."));
        }
        return out;
    }

    static Reminder byId(Context c, String id) {
        for (Reminder r : reminders(c)) if (r.id.equals(id)) return r;
        return null;
    }

    private static void parseSlots(List<Reminder> out, String packed, boolean med) {
        if (packed == null || packed.isEmpty()) return;
        for (String item : packed.split("\\|")) {
            String[] a = item.split("@", 2);
            if (a.length != 2 || !validTime(a[1])) continue;
            String code = a[0], time = a[1];
            String ko = slotLabel(code);
            if (ko.isEmpty()) continue;
            if (med) {
                out.add(new Reminder("med_" + code, "med", ko + " 약", time,
                    ko + " 약을 챙길 시간입니다."));
            } else {
                if ("bed".equals(code)) continue;
                out.add(new Reminder("eat_" + code, "eat", ko + " 식사", time,
                    ko + " 식사를 챙길 시간입니다."));
            }
        }
    }

    static String slotLabel(String c) {
        if ("am".equals(c)) return "아침";
        if ("noon".equals(c)) return "점심";
        if ("pm".equals(c)) return "저녁";
        if ("bed".equals(c)) return "자기 전";
        return "";
    }

    static boolean validTime(String t) {
        if (t == null || !t.matches("\\d{2}:\\d{2}")) return false;
        try {
            String[] a = t.split(":");
            int h = Integer.parseInt(a[0]), m = Integer.parseInt(a[1]);
            return h >= 0 && h < 24 && m >= 0 && m < 60;
        } catch (Exception e) { return false; }
    }

    private static String safe(String x) { return x == null ? "" : x; }
}
