package io.github.hantae_ho.twa;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;

final class NotificationHelper {
    private static final String CHANNEL = "recovery_reminders_v1";
    private NotificationHelper() {}

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "회복 챙기기", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("복약·식사·잠·위험시간대 예약알림");
        ch.enableLights(true);
        ch.setLightColor(Color.rgb(36,121,143));
        nm.createNotificationChannel(ch);
    }

    static boolean canPost(Context c) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return false;
        if (Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = nm.getNotificationChannel(CHANNEL);
            if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) return false;
        }
        return true;
    }

    static boolean showReminder(Context c, Reminder r) {
        if (!canPost(c)) return false;
        ensureChannel(c);
        boolean detailed = ReminderStore.detailed(c);
        String body = detailed ? r.detailBody : "챙길 시간입니다. 오늘 한 걸음을 열어 확인해주세요.";
        return post(c, r.id.hashCode() & 0x7fffffff, body);
    }

    static boolean showTest(Context c) {
        if (!canPost(c)) return false;
        ensureChannel(c);
        return post(c, 800001, "시험 알림입니다. 앱을 완전히 닫아도 예약알림은 Android가 보관합니다.");
    }

    private static boolean post(Context c, int id, String body) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return false;
        Intent open = new Intent(c, MainActivity.class);
        open.setAction(Intent.ACTION_VIEW);
        open.setData(Uri.parse("https://hantae-ho.github.io/oneul-web/index.html?native=1&from=reminder"));
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(c, 800002, open, pf);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(c, CHANNEL)
            : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notification)
         .setContentTitle("오늘 한 걸음")
         .setContentText(body)
         .setStyle(new Notification.BigTextStyle().bigText(body))
         .setContentIntent(pi)
         .setAutoCancel(true)
         .setVisibility(Notification.VISIBILITY_PRIVATE)
         .setColor(Color.rgb(36,121,143));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_DEFAULT);
        nm.notify(id, b.build());
        return true;
    }
}
