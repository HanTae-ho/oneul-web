package io.github.hantae_ho.twa;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class NotificationSettingsActivity extends Activity {
    private static final int REQ_NOTIFY = 800;
    private Switch enabledSwitch, detailedSwitch;
    private TextView status, summary;
    private String pendingRisk = "", pendingMeds = "", pendingEats = "", pendingBed = "", pendingBuild = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        NotificationHelper.ensureChannel(this);
        loadPendingFromPrefs();
        importFromIntent(getIntent());
        buildUi();
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        importFromIntent(i);
        refresh();
    }

    private void loadPendingFromPrefs() {
        android.content.SharedPreferences p = ReminderStore.prefs(this);
        pendingRisk = p.getString(ReminderStore.KEY_RISK, "");
        pendingMeds = p.getString(ReminderStore.KEY_MEDS, "");
        pendingEats = p.getString(ReminderStore.KEY_EATS, "");
        pendingBed = p.getString(ReminderStore.KEY_BED, "");
        pendingBuild = p.getString(ReminderStore.KEY_BUILD, "");
    }

    private void importFromIntent(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u == null || !"oneul".equals(u.getScheme()) || !"reminders".equals(u.getHost())) return;
        // Stage only. A deep link can never silently change active alarms; Save is required.
        pendingRisk = val(u,"risk");
        pendingMeds = val(u,"meds");
        pendingEats = val(u,"eats");
        pendingBed = val(u,"bed");
        pendingBuild = val(u,"build");
    }

    private String val(Uri u, String k) { String v = u.getQueryParameter(k); return v == null ? "" : v; }

    private void buildUi() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        final int padH = dp(22), padTop = dp(22), padBottom = dp(30);
        root.setPadding(padH, padTop, padH, padBottom);
        root.setBackgroundColor(Color.rgb(244,248,250));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(padH, padTop + insets.getSystemWindowInsetTop(),
                padH, padBottom + insets.getSystemWindowInsetBottom());
            return insets;
        });
        sc.addView(root);

        TextView title = text("예약 알림", 27, true);
        root.addView(title);
        TextView intro = text("앱이 화면에 없거나 프로세스가 종료되어도 Android가 예약을 보관합니다. 서버로 일정이나 회복기록을 보내지 않습니다.", 16, false);
        intro.setTextColor(Color.rgb(70,85,90)); intro.setPadding(0,dp(8),0,dp(20)); root.addView(intro);

        enabledSwitch = new Switch(this);
        enabledSwitch.setText("예약 알림 사용");
        enabledSwitch.setTextSize(18); enabledSwitch.setPadding(0,dp(8),0,dp(8));
        enabledSwitch.setChecked(ReminderStore.enabled(this));
        root.addView(enabledSwitch);

        detailedSwitch = new Switch(this);
        detailedSwitch.setText("잠금화면 알림에 구체적 내용 표시");
        detailedSwitch.setTextSize(16); detailedSwitch.setPadding(0,dp(8),0,dp(8));
        detailedSwitch.setChecked(ReminderStore.detailed(this));
        root.addView(detailedSwitch);
        TextView privacy = text("기본값은 꺼짐입니다. 꺼두면 ‘챙길 시간입니다’처럼 중립적인 문구만 보여 개인정보 노출을 줄입니다.", 14, false);
        privacy.setTextColor(Color.GRAY); privacy.setPadding(0,0,0,dp(18)); root.addView(privacy);

        TextView h = text("현재 가져온 시간", 19, true); h.setPadding(0,dp(8),0,dp(8)); root.addView(h);
        summary = text("", 16, false); summary.setPadding(dp(14),dp(14),dp(14),dp(14)); summary.setBackgroundColor(Color.WHITE); root.addView(summary);

        status = text("", 14, false); status.setPadding(0,dp(14),0,dp(8)); root.addView(status);

        Button permission = button("Android 알림 권한 확인");
        permission.setOnClickListener(v -> openAppNotificationSettings()); root.addView(permission);

        Button test = button("시험 알림 보내기");
        test.setOnClickListener(v -> testNotification()); root.addView(test);

        Button save = button("저장하고 앱으로 돌아가기");
        save.setOnClickListener(v -> { saveState(); openWebApp(); }); root.addView(save);

        TextView note = text("※ 정확한 알람 특수권한을 사용하지 않는 방식이라 Android의 절전·배터리 정책에 따라 알림이 설정 시각보다 늦어질 수 있습니다. 앱을 ‘강제중지’하면 예약도 멈추며, 앱을 다시 열어야 재개됩니다.", 13, false);
        note.setTextColor(Color.GRAY); note.setPadding(0,dp(18),0,0); root.addView(note);

        enabledSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !NotificationHelper.canPost(this) && Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            }
            refreshStatus();
        });

        setContentView(sc);
        refresh();
    }

    private void refresh() {
        if (summary != null) summary.setText(summaryText());
        refreshStatus();
    }

    private void refreshStatus() {
        if (status == null) return;
        int n = ReminderStore.fromPacked(pendingRisk, pendingMeds, pendingEats, pendingBed).size();
        String p = NotificationHelper.canPost(this) ? "알림 권한 허용됨" : "알림 권한 필요";
        status.setText("예약 " + n + "개 · " + p + (enabledSwitch != null && enabledSwitch.isChecked() ? " · 저장 시 사용" : " · 저장 시 끔"));
        status.setTextColor(NotificationHelper.canPost(this) ? Color.rgb(30,115,90) : Color.rgb(180,80,40));
    }

    private String summaryText() {
        List<Reminder> list = ReminderStore.fromPacked(pendingRisk, pendingMeds, pendingEats, pendingBed);
        if (list.isEmpty()) return "설정된 시간이 없습니다. 오늘 한 걸음 → 내 정보 → 챙기기에서 시간을 정한 뒤 다시 열어주세요.";
        StringBuilder b = new StringBuilder();
        for (Reminder r : list) b.append("• ").append(r.label).append("  ").append(r.time).append("\n");
        return b.toString().trim();
    }

    private void saveState() {
        ReminderStore.importSchedule(this, pendingRisk, pendingMeds, pendingEats, pendingBed, pendingBuild);
        ReminderStore.setDetailed(this, detailedSwitch.isChecked());
        ReminderStore.setEnabled(this, enabledSwitch.isChecked());
        if (enabledSwitch.isChecked() && !NotificationHelper.canPost(this))
            Toast.makeText(this, "Android 알림 권한을 허용해야 알림이 표시됩니다.", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "예약알림 설정을 저장했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void testNotification() {
        if (!NotificationHelper.canPost(this)) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            else openAppNotificationSettings();
            return;
        }
        boolean ok = NotificationHelper.showTest(this);
        Toast.makeText(this, ok ? "시험 알림을 보냈습니다." : "알림을 보내지 못했습니다.", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshStatus();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_NOTIFY) {
            refreshStatus();
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "알림 권한을 허용했습니다.", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "알림 권한이 허용되지 않았습니다.", Toast.LENGTH_LONG).show();
        }
    }

    private void openAppNotificationSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(i);
    }

    private void openWebApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://hantae-ho.github.io/oneul-web/index.html?native=1"));
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.rgb(25,35,38));
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54)); lp.setMargins(0,dp(8),0,0); b.setLayoutParams(lp); return b;
    }
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }
}
