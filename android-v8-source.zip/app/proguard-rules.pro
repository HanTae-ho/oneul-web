# V8.0: no custom shrinking rules required.
