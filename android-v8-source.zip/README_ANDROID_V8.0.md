# 오늘 한 걸음 V8.0 Android 네이티브 예약알림

## 구조
- 웹 UI/PWA: `https://hantae-ho.github.io/oneul-web/`
- Android package: `io.github.hantae_ho.twa` (기존 패키지 유지)
- TWA 시작 URL: `https://hantae-ho.github.io/oneul-web/index.html?native=1`
- 웹의 [Android 예약알림 설정] → `oneul://reminders` 딥링크 → 네이티브 설정 Activity
- 예약: `AlarmManager.setAndAllowWhileIdle()` one-shot + 알림 후 다음날 재예약
- 재부팅/시간대 변경/앱 업데이트 후 재등록

## 개인정보
Android로 전달되는 값은 다음뿐입니다.
- 위험시간대의 시(hour)
- 복약 슬롯(아침/점심/저녁/자기 전)과 시각
- 식사 슬롯과 시각
- 취침 시각
약 이름, 회복 시작일, 갈망/재발, 선별점수, 상담/AI 기록은 전달하지 않습니다.

## 왜 exact alarm을 쓰지 않았나
`SCHEDULE_EXACT_ALARM`은 특수 앱 접근 권한이고 Android 14 이후 신규 설치에서 기본 허용되지 않습니다. 회복지원 알림은 알람시계/캘린더와 같은 exact-alarm 핵심 용도로 보기 어렵기 때문에 V8.0은 `setAndAllowWhileIdle()`을 사용합니다. 앱이 완전히 닫혀 있어도 동작하지만 OS 절전 정책에 따라 다소 늦어질 수 있습니다.

## 최종 릴리스 서명
기존 앱과 동일한 package 및 기존 `signing.keystore`로 서명해야 업데이트 설치가 됩니다.
- package: `io.github.hantae_ho.twa`
- versionCode: 800
- versionName: 8.0

기존 keystore는 GitHub에 절대 올리지 않습니다.
